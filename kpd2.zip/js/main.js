const swiper = new Swiper(".swiper", {
  slidesPerView: 1,
  pagination: {
    el: ".swiper-pagination",
  },
});


function tabs(headerSelector, tabSelector, contentSelector, activeClass, display = 'flex') {
  const header = document.querySelector(headerSelector),
    tab = document.querySelectorAll(tabSelector),
    content = document.querySelectorAll(contentSelector)
  function hideTabContent() {
    content.forEach(item => {
      item.style.display = 'none'
    });
    tab.forEach(item => {
      item.classList.remove(activeClass)
    });
  }
  function showTabContent(i = 0) {
    content[i].style.display = display
    tab[i].classList.add(activeClass)
  }
  hideTabContent()
  showTabContent()
  header.addEventListener('click', e => {
    const target = e.target
    if (target.classList.contains(tabSelector.replace(/\./, '')) ||
      target.parentNode.classList.contains(tabSelector.replace(/\./, ''))) {
      tab.forEach((item, i) => {
        if (target == item || target.parentNode == item) {
          hideTabContent()
          showTabContent(i)
        }
      });
    }
  })
}

// ПЕРВЫЙ аргумент - класс всего нашего хедера табов.
// ВТОРОЙ аргумент - класс конкретного элемента, при клике на который будет переключатся таб.
// ТРЕТИЙ аргумент - класс того блока, который будет переключаться.
// ЧЕТВЕРТЫЙ аргумент - класс активности, который будет добавлятся для таба, который сейчас активен.
tabs('.tabs__header', '.tabs__header-item', '.tabs__content-item', 'active')

function productPreviewSlider() {
  const container = document.querySelector('.cardproduct-section-block-slider');

  if (!container) {
    return null
  }
  // Получаем список всех элементов swiper-slider-dot
  const selectItems = document.querySelectorAll('.swiper-slider-dot');

  // Получаем swiper
  const swiper = new Swiper('.cardproduct-section-block-slider', {
    slidesPerView: 1,
  });
  function removeActive() {
    selectItems.forEach(selectItem => {
      selectItem.classList.remove('active')
    });

  }


  // Добавляем обработчик события клика на каждый элемент swiper-slider-dot
  selectItems.forEach((item, index) => {
    item.addEventListener('click', () => {
      // Активируем соответствующий слайд в swiper
      swiper.slideTo(index);
      removeActive()
      item.classList.add('active')
    });
  });
}
productPreviewSlider()

function init() {

  let map = new ymaps.Map('map', {
    center: [55.75554289958026, 37.64131907421875],
    zoom: 9

  });
}

ymaps.ready(init);

function init() {
  let map = new ymaps.Map1('map1', {
    center: [55.75554289958026, 37.64131907421875],
    zoom: 9

  });
}

ymaps.ready(init);


